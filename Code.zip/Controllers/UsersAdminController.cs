﻿using BookStore.Models;
using Microsoft.AspNet.Identity.Owin;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace BookStore.Controllers
{
	[Authorize(Roles = "Admin")]
	public class UsersAdminController : Controller
	{

		public UsersAdminController()
		{
		}
		public UsersAdminController(ApplicationUserManager userManager, ApplicationRoleManager roleManager)
		{
			UserManager = userManager;
			RoleManager = roleManager;
		}
		private ApplicationUserManager _userManager;
		public ApplicationUserManager UserManager
		{
			get
			{
				return _userManager ??
			   HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
			}
			private set
			{
				_userManager = value;
			}
		}

		private ApplicationRoleManager _roleManager;
		public ApplicationRoleManager RoleManager
		{
			get
			{
				return _roleManager ??
			   HttpContext.GetOwinContext().Get<ApplicationRoleManager>();
			}
			private set
			{
				_roleManager = value;
			}
		}


		// GET: UsersAdmin
		public async Task<ActionResult> Index()
		{
			return View(await UserManager.Users.ToListAsync());
		}


		// GET: UsersAdmin/Details/5
		public async Task<ActionResult> Details(string id)
		{
			if (id == null)
			{
				return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
			}
			var user = await UserManager.FindByIdAsync(id);
			ViewBag.RoleNames = await UserManager.GetRolesAsync(user.Id);
			return View(user);
		}

		// GET: UsersAdmin/Create
		public async Task<ActionResult> Create()
		{
			ViewBag.RoleId = new SelectList(await RoleManager.Roles.ToListAsync(), "Name", "Name");
			return View();
		}

		// POST: UsersAdmin/Create
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<ActionResult> Create(RegisterViewModel userViewModel, string[] selectedRoles)
		{
			if (ModelState.IsValid)
			{
				var user = new ApplicationUser
				{
					UserName = userViewModel.Name,
					Name = userViewModel.Name,
					Address = userViewModel.Address
				};
				var adminresult = await UserManager.CreateAsync(user, userViewModel.Password);
				if (adminresult.Succeeded)
				{
					if (selectedRoles != null)
					{
						var result = await UserManager.AddToRolesAsync(user.Id, selectedRoles);
						if (!result.Succeeded)
						{
							ModelState.AddModelError("", result.Errors.First());
							ViewBag.RoleId = new SelectList(await
							RoleManager.Roles.ToListAsync(), "Name", "Name");
							return View();
						}
					}
				}
				else
				{
					ModelState.AddModelError("", adminresult.Errors.First());
					ViewBag.RoleId = new SelectList(RoleManager.Roles, "Name",
					"Name");
					return View();
				}
				return RedirectToAction("Index");
			}
			ViewBag.RoleId = new SelectList(RoleManager.Roles, "Name", "Name");
			return View();
		}
	}
}
