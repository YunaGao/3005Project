﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using BookStore.Models;

namespace BookStore.Controllers
{
	[Authorize(Roles = "Admin")]	public class PublishersController : Controller
	{
		private StoreContext db = new StoreContext();

		[AllowAnonymous]
		// GET: Categories
		public ActionResult Index()
		{
			return View(db.Publishers.ToList());
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				db.Dispose();
			}
			base.Dispose(disposing);
		}
	}
}
