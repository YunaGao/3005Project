﻿using BookStore.Models;
using BookStore.Models.ViewModels;
using System.Web.Mvc;

namespace BookStore.Controllers
{
	public class BasketController : Controller
	{
		public ActionResult Index()
		{
			Basket basket = Basket.GetBasket();
			BasketViewModel viewModel = new BasketViewModel
			{
				BasketItems = basket.GetBasketItems(),
				TotalCost = basket.GetTotalCost()
			};
			return View(viewModel);
		}

		[ValidateAntiForgeryToken]
		public ActionResult AddToBasket(int id, int amount)
		{
			Basket basket = Basket.GetBasket();
			basket.AddToBasket(id, amount);
			return RedirectToAction("Index");

		}
		[HttpPost]
		[ValidateAntiForgeryToken]
		public ActionResult UpdateBasket(BasketViewModel viewModel)
		{
			Basket basket = Basket.GetBasket();
			basket.UpdateBasket(viewModel.BasketItems);
			return RedirectToAction("Index");
		}
		[HttpGet]
		public ActionResult RemoveLine(int id)
		{
			Basket basket = Basket.GetBasket();
			basket.RemoveItem(id);
			return RedirectToAction("Index");
		}

		public PartialViewResult Summary()
		{
			Basket basket = Basket.GetBasket();
			BasketSummaryViewModel viewModel = new BasketSummaryViewModel
			{
				NumberOfItems = basket.GetNumberOfItems(),
				TotalCost = basket.GetTotalCost()
			};
			return PartialView(viewModel);
		}
	}
}