﻿using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using BookStore.Models;
using Microsoft.AspNet.Identity.Owin;

namespace BookStore.Controllers
{
	[Authorize]
	public class OrdersController : Controller
	{
		private StoreContext db = new StoreContext();

		private ApplicationUserManager _userManager;
		public ApplicationUserManager UserManager
		{
			get
			{
				return _userManager ??
			   HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
			}
			private set
			{
				_userManager = value;
			}
		}
		private ApplicationRoleManager _roleManager;
		public ApplicationRoleManager RoleManager
		{
			get
			{
				return _roleManager ??
			   HttpContext.GetOwinContext().Get<ApplicationRoleManager>();
			}
			private set
			{
				_roleManager = value;
			}
		}

		// GET: Orders
		public ActionResult Index()
		{
			var orders = db.Orders.OrderBy(o => o.Status).Include(o => o.OrderLines);
			if (!User.IsInRole("Admin"))
			{
				orders = orders.Where(o => o.UserID == User.Identity.Name);
			}
			return View(orders);
		}


		// GET: Orders/Details/5
		public ActionResult Details(int? id)
		{
			if (id == null)
			{
				return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
			}
			Order order = db.Orders.Include(o => o.OrderLines).Where(o => o.ID == id).SingleOrDefault();
			if (order == null)
			{
				return HttpNotFound();
			}
			if (order.UserID == User.Identity.Name || User.IsInRole("Admin"))
			{
				return View(order);
			}
			else
			{
				return new HttpStatusCodeResult(HttpStatusCode.Unauthorized);
			}
		}

		// GET: Orders/Create
		public async Task<ActionResult> Review()
		{
			Basket basket = Basket.GetBasket();
			Order order = new Models.Order();
			order.UserID = User.Identity.Name;
			ApplicationUser user = await UserManager.FindByNameAsync(order.UserID);

			if (user == null)
			{
				return View("../Account/Login");
			}

			order.DeliveryName = user.Name;
			order.DeliveryAddress = user.Address;
			order.OrderLines = new List<OrderItem>();
			foreach (var basketLine in basket.GetBasketItems())
			{
				OrderItem line = new OrderItem
				{
					Book = basketLine.Book,
					BookID = basketLine.BookID,
					BookName = basketLine.Book.Name,
					Amount = basketLine.Amount,
					Price = basketLine.Book.Price
				};
				order.OrderLines.Add(line);
			}
			order.TotalPrice = basket.GetTotalCost();
			return View(order);
		}

		// GET: Orders/Edit/5
		public ActionResult Edit(int? id)
		{
			if (id == null)
			{
				return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
			}
			Order order = db.Orders.Find(id);
			if (order == null)
			{
				return HttpNotFound();
			}
			return View(order);
		}

		// GET: Orders/Delete/5
		public ActionResult Delete(int? id)
		{
			if (id == null)
			{
				return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
			}
			Order order = db.Orders.Find(id);
			if (order == null)
			{
				return HttpNotFound();
			}
			return View(order);
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public ActionResult Create([Bind(Include = "UserID,DeliveryName,DeliveryAddress")] Order order)
		{
			if (ModelState.IsValid)
			{
				order.Status = "Pending";
				db.Orders.Add(order);
				db.SaveChanges();
				Basket basket = Basket.GetBasket();
				order.TotalPrice = basket.CreateOrderItems(order.ID);
				db.SaveChanges();
				return RedirectToAction("Details", new { id = order.ID });
			}
			return RedirectToAction("Review");
		}

		// POST: Orders/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public ActionResult DeleteConfirmed(int id)
		{
			Order order = db.Orders.Find(id);
			db.Orders.Remove(order);
			db.SaveChanges();
			return RedirectToAction("Index");
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				db.Dispose();
			}
			base.Dispose(disposing);
		}
	}
}
