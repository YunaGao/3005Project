﻿using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using BookStore.Models;
using BookStore.Models.ViewModels;

namespace BookStore.Controllers
{
	[Authorize(Roles = "Admin")]
	public class BooksController : Controller
	{
		private StoreContext db = new StoreContext();

		// GET: Products
		[AllowAnonymous]
		public ActionResult Index(string search)
		{
			var products = db.Books.Include(p => p.Publisher);
			if (!string.IsNullOrEmpty(search))
			{
				products = products.Where(p => p.Name.Contains(search) ||
				p.ISBN.Contains(search) ||
			   p.Publisher.Name.Contains(search));
			}
			return View(products);
		}

		[AllowAnonymous]
		// GET: Products/Details/5
		public ActionResult Details(int? id)
		{
			if (id == null)
			{
				return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
			}
			Book product = db.Books.Find(id);
			if (product == null)
			{
				return HttpNotFound();
			}
			return View(product);
		}

		// POST: Products/Create
		// To protect from overposting attacks, please enable the specific properties you want to bind to, for 
		// more details see https://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		public ActionResult Create(BookViewModel viewModel)
		{
			Book product = new Book();
			product.Name = viewModel.Name;
			product.ISBN = viewModel.ISBN;
			product.Price = viewModel.Price;
			product.PublisherId = viewModel.PublisherId;
			if (ModelState.IsValid)
			{
				db.Books.Add(product);
				db.SaveChanges();
				return RedirectToAction("Index");
			}
			viewModel.Publishers = new SelectList(db.Publishers, "ID", "Name", product.PublisherId);
			return View(viewModel);
		}


		// GET: Products/Edit/5
		public ActionResult Edit(int? id)
		{
			if (id == null)
			{
				return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
			}
			Book product = db.Books.Find(id);
			if (product == null)
			{
				return HttpNotFound();
			}
			BookViewModel viewModel = new BookViewModel();
			viewModel.Publishers = new SelectList(db.Publishers, "ID", "Name", product.PublisherId);
			viewModel.ImageLists = new List<SelectList>();
			viewModel.ID = product.ID;
			viewModel.Name = product.Name;
			viewModel.ISBN = product.ISBN;
			viewModel.Price = product.Price;
			return View(viewModel);
		}


		// GET: Products/Delete/5
		public ActionResult Delete(int? id)
		{
			if (id == null)
			{
				return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
			}
			Book product = db.Books.Find(id);
			if (product == null)
			{
				return HttpNotFound();
			}
			return View(product);
		}

		// POST: Products/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public ActionResult DeleteConfirmed(int id)
		{
			Book product = db.Books.Find(id);
			db.Books.Remove(product);
			var orderLines = db.OrderItems.Where(ol => ol.BookID == id);
			foreach (var ol in orderLines)
			{
				ol.BookID = null;
			}
			db.SaveChanges();
			return RedirectToAction("Index");
		}


		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				db.Dispose();
			}
			base.Dispose(disposing);
		}
	}
}
