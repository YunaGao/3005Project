﻿using System.Data.Entity.Migrations;

namespace BookStore.Migrations
{

	public partial class InitBookStore : DbMigration
	{
		public override void Up()
		{
			

			CreateTable(
				"dbo.Publishers",
				c => new
				{
					ID = c.Int(nullable: false, identity: true),
					Name = c.String(nullable: false, maxLength: 50)
				})
				.PrimaryKey(t => t.ID);

			CreateTable(
				"dbo.Contacts",
				c => new
				{
					ID = c.Int(nullable: false, identity: true),
					Phone = c.String(nullable: false, maxLength: 50),
					PublisherID = c.Int(),
				})
				.PrimaryKey(t => t.ID)
				.ForeignKey("dbo.Publishers", t => t.PublisherID)
				.Index(t => t.PublisherID);

			CreateTable(
				"dbo.Authors",
				c => new
				{
					ID = c.Int(nullable: false, identity: true),
					Name = c.String(nullable: false, maxLength: 50)
				})
				.PrimaryKey(t => t.ID);

			CreateTable(
				"dbo.Books",
				c => new
				{
					ID = c.Int(nullable: false, identity: true),
					Pages = c.Int(nullable: false),
					Name = c.String(nullable: false, maxLength: 50),
					Genre = c.String(nullable: false, maxLength: 50),
					ISBN = c.String(nullable: false, maxLength: 200),
					Price = c.Decimal(nullable: false, precision: 18, scale: 2),
					PublisherID = c.Int()
				})
				.PrimaryKey(t => t.ID)
				.ForeignKey("dbo.Publishers", t => t.PublisherID)
				.Index(t => t.PublisherID);

			CreateTable(
				"dbo.BankingAccounts",
				c => new
				{
					ID = c.Int(nullable: false, identity: true),
					BookID = c.Int(nullable: false, identity: true),
					Percentage = c.Decimal(nullable: false, precision: 18, scale: 2)
				})
				.PrimaryKey(t => t.ID)
				.ForeignKey("dbo.Books", t => t.BookID)
				.Index(t => t.BookID);

			CreateTable(
				"dbo.BasketItems",
				c => new
				{
					ID = c.Int(nullable: false, identity: true),
					BasketID = c.String(),
					BookID = c.Int(nullable: false),
					Amount = c.Int(nullable: false)
				})
				.PrimaryKey(t => t.ID)
				.ForeignKey("dbo.Books", t => t.BookID, cascadeDelete: true)
				.Index(t => t.BookID);

			CreateTable(
				"dbo.OrderItems",
				c => new
				{
					ID = c.Int(nullable: false, identity: true),
					OrderID = c.Int(nullable: false),
					BookID = c.Int(),
					Amount = c.Int(nullable: false),
					BookName = c.String(),
					Price = c.Decimal(nullable: false, precision: 18, scale: 2)
				})
				.PrimaryKey(t => t.ID)
				.ForeignKey("dbo.Orders", t => t.OrderID, cascadeDelete: true)
				.ForeignKey("dbo.Books", t => t.BookID)
				.Index(t => t.OrderID)
				.Index(t => t.BookID);

			CreateTable(
				"dbo.Orders",
				c => new
				{
					OrderID = c.Int(nullable: false, identity: true),
					UserID = c.String(),
					DeliveryName = c.String(),
					DeliveryAddress = c.String(nullable: false),
					TotalPrice = c.Decimal(nullable: false, precision: 18, scale: 2)
				})
				.PrimaryKey(t => t.OrderID);

		}

		public override void Down()
		{
			
			DropForeignKey("dbo.Contacts", "PublisherID", "dbo.Publishers");
			DropIndex("dbo.Contacts", new[] { "PublisherID" });

			DropForeignKey("dbo.Books", "PublisherID", "dbo.Publishers");
			DropIndex("dbo.Books", new[] { "PublisherID" });


			DropForeignKey("dbo.BasketItems", "BookID", "dbo.Books");
			DropIndex("dbo.BasketItems", new[] { "BookID" });

			DropForeignKey("dbo.OrderItems", "BookID", "dbo.Books");
			DropForeignKey("dbo.OrderItems", "OrderID", "dbo.Orders");
			DropIndex("dbo.OrderItems", new[] { "BookID" });
			DropIndex("dbo.OrderItems", new[] { "OrderID" });


			DropTable("dbo.Authors");
			DropTable("dbo.Contacts");
			DropTable("dbo.Books");
			DropTable("dbo.Publishers");
			DropTable("dbo.BasketItems");

			DropTable("dbo.Orders");
			DropTable("dbo.OrderItems");
		}
	}
}
