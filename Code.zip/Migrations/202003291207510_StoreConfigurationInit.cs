﻿namespace BookStore.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class StoreConfigurationInit : DbMigration
    {
        public override void Up()
        {
			CreateTable(
				"dbo.AspNetRoles",
				c => new
				{
					Id = c.String(nullable: false, maxLength: 128),
					Name = c.String(nullable: false, maxLength: 256),
				})
				.PrimaryKey(t => t.Id)
				.Index(t => t.Name, unique: true, name: "RoleNameIndex");

			CreateTable(
				"dbo.AspNetUserRoles",
				c => new
				{
					UserId = c.String(nullable: false, maxLength: 128),
					RoleId = c.String(nullable: false, maxLength: 128),
				})
				.PrimaryKey(t => new { t.UserId, t.RoleId })
				.ForeignKey("dbo.AspNetRoles", t => t.RoleId, cascadeDelete: true)
				.ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
				.Index(t => t.UserId)
				.Index(t => t.RoleId);

			CreateTable(
				"dbo.AspNetUsers",
				c => new
				{
					Id = c.String(nullable: false, maxLength: 128),
					Name = c.String(nullable: false, maxLength: 50),
					Address = c.String(nullable: false),
					PasswordHash = c.String(),
					SecurityStamp = c.String(),
					UserName = c.String(nullable: false, maxLength: 256),
				})
				.PrimaryKey(t => t.Id)
				.Index(t => t.UserName, unique: true, name: "UserNameIndex");

			CreateTable(
				"dbo.AspNetUserClaims",
				c => new
				{
					Id = c.Int(nullable: false, identity: true),
					UserId = c.String(nullable: false, maxLength: 128),
					ClaimType = c.String(),
					ClaimValue = c.String(),
				})
				.PrimaryKey(t => t.Id)
				.ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
				.Index(t => t.UserId);

			CreateTable(
				"dbo.AspNetUserLogins",
				c => new
				{
					LoginProvider = c.String(nullable: false, maxLength: 128),
					ProviderKey = c.String(nullable: false, maxLength: 128),
					UserId = c.String(nullable: false, maxLength: 128),
				})
				.PrimaryKey(t => new { t.LoginProvider, t.ProviderKey, t.UserId })
				.ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
				.Index(t => t.UserId);

            CreateTable(
                "dbo.Authors",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Book_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Books", t => t.Book_ID)
                .Index(t => t.Book_ID);
            
            CreateTable(
                "dbo.BankingAccounts",
                c => new
                    {
                        ID = c.Int(nullable: false),
                        BookId = c.Int(nullable: false),
                        Percentage = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => new { t.ID, t.BookId });
            
            CreateTable(
                "dbo.BasketItems",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        BasketID = c.String(),
                        BookID = c.Int(nullable: false),
                        Amount = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Books", t => t.BookID, cascadeDelete: true)
                .Index(t => t.BookID);
            
            CreateTable(
                "dbo.Books",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        ISBN = c.String(),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Pages = c.Int(nullable: false),
                        PublisherId = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Publishers", t => t.PublisherId)
                .Index(t => t.PublisherId);
            
            CreateTable(
                "dbo.Publishers",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Address = c.String(),
                        BankingAccId = c.Int(),
                        BankingAccount_ID = c.Int(),
                        BankingAccount_BookId = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.BankingAccounts", t => new { t.BankingAccount_ID, t.BankingAccount_BookId })
                .Index(t => new { t.BankingAccount_ID, t.BankingAccount_BookId });
            
            CreateTable(
                "dbo.Contacts",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        PublisherID = c.Int(nullable: false),
                        Phone = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.OrderItems",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        OrderID = c.Int(nullable: false),
                        BookID = c.Int(),
                        Amount = c.Int(nullable: false),
                        BookName = c.String(),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Books", t => t.BookID)
                .ForeignKey("dbo.Orders", t => t.OrderID, cascadeDelete: true)
                .Index(t => t.OrderID)
                .Index(t => t.BookID);
            
            CreateTable(
                "dbo.Orders",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        UserID = c.String(),
                        DeliveryName = c.String(),
                        DeliveryAddress = c.String(),
                        TotalPrice = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Status = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
			DropForeignKey("dbo.AspNetUserRoles", "UserId", "dbo.AspNetUsers");
			DropForeignKey("dbo.AspNetUserLogins", "UserId", "dbo.AspNetUsers");
			DropForeignKey("dbo.AspNetUserClaims", "UserId", "dbo.AspNetUsers");
			DropForeignKey("dbo.AspNetUserRoles", "RoleId", "dbo.AspNetRoles");
			DropIndex("dbo.AspNetUserLogins", new[] { "UserId" });
			DropIndex("dbo.AspNetUserClaims", new[] { "UserId" });
			DropIndex("dbo.AspNetUsers", "UserNameIndex");
			DropIndex("dbo.AspNetUserRoles", new[] { "RoleId" });
			DropIndex("dbo.AspNetUserRoles", new[] { "UserId" });
			DropIndex("dbo.AspNetRoles", "RoleNameIndex");
			DropTable("dbo.AspNetUserLogins");
			DropTable("dbo.AspNetUserClaims");
			DropTable("dbo.AspNetUsers");
			DropTable("dbo.AspNetUserRoles");
			DropTable("dbo.AspNetRoles");
            DropForeignKey("dbo.OrderItems", "OrderID", "dbo.Orders");
            DropForeignKey("dbo.OrderItems", "BookID", "dbo.Books");
            DropForeignKey("dbo.BasketItems", "BookID", "dbo.Books");
            DropForeignKey("dbo.Books", "PublisherId", "dbo.Publishers");
            DropForeignKey("dbo.Publishers", new[] { "BankingAccount_ID", "BankingAccount_BookId" }, "dbo.BankingAccounts");
            DropForeignKey("dbo.Authors", "Book_ID", "dbo.Books");
            DropIndex("dbo.OrderItems", new[] { "BookID" });
            DropIndex("dbo.OrderItems", new[] { "OrderID" });
            DropIndex("dbo.Publishers", new[] { "BankingAccount_ID", "BankingAccount_BookId" });
            DropIndex("dbo.Books", new[] { "PublisherId" });
            DropIndex("dbo.BasketItems", new[] { "BookID" });
            DropIndex("dbo.Authors", new[] { "Book_ID" });
            DropTable("dbo.Orders");
            DropTable("dbo.OrderItems");
            DropTable("dbo.Contacts");
            DropTable("dbo.Publishers");
            DropTable("dbo.Books");
            DropTable("dbo.BasketItems");
            DropTable("dbo.BankingAccounts");
            DropTable("dbo.Authors");
        }
    }
}
