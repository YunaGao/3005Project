﻿using BookStore.Models;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;

namespace BookStore.Migrations
{
	internal sealed class StoreConfiguration : DbMigrationsConfiguration<StoreContext>
	{
		public StoreConfiguration()
		{
			AutomaticMigrationsEnabled = true;
		}

		protected override void Seed(StoreContext context)
		{
			var publishers = new List<Publisher>
			 {
				new Publisher {ID = 1, Name = "Publisher 1", Address = "Addr 1" },
				new Publisher {ID = 2, Name = "Publisher 2", Address = "Addr 1" }
			 };

			publishers.ForEach(c => context.Publishers.AddOrUpdate(p => p.Name, c));
			context.SaveChanges();

			var contacts = new List<Contact>
			 {
				new Contact {ID = 1, Phone = "Phone 1", PublisherID = publishers.Single(c => c.Name  ==  "Publisher 1").ID },
				new Contact {ID = 2, Phone = "Phone 2", PublisherID = publishers.Single(c => c.Name  ==  "Publisher 2").ID }
			 };

			contacts.ForEach(c => context.Contacts.AddOrUpdate(p => p.ID, c));
			context.SaveChanges();

			var authors = new List<Author>
			 {
				new Author {ID = 1, Name = "Author 1" },
				new Author {ID = 2, Name = "Author 2" }
			 };

			authors.ForEach(c => context.Authors.AddOrUpdate(p => p.Name, c));
			context.SaveChanges();

			var books = new List<Book>
			 {
				new Book {
					ID = 1, Name = "Computers Book", ISBN = "1", Price = 631, Pages = 100, Authors = new List<Author>
					{
						authors.First()
					},
					PublisherId = publishers.Single(c => c.Name  ==  "Publisher 1").ID
				},
				new Book {
					ID = 2, Name = "Gaming Book", ISBN = "2", Price = 239, Pages = 200, Authors = new List<Author>
					{
						authors.Last()
					},
					PublisherId = publishers.Single(c => c.Name  ==  "Publisher 1").ID
				},
				new Book {
					ID = 3, Name = "Networking Book", ISBN = "3", Price = 369, Pages = 300, Authors = authors,
					PublisherId = publishers.Single(c => c.Name  ==  "Publisher 2").ID
				}
			};

			books.ForEach(c => context.Books.AddOrUpdate(p => p.Name, c));
			context.SaveChanges();

			var bankingaccounts = new List<BankingAccount>
			 {
				new BankingAccount {ID = 1, BookId = 1, Percentage = 0.3m },
				new BankingAccount {ID = 1, BookId = 2, Percentage = 0.4m },
				new BankingAccount {ID = 2, BookId = 3, Percentage = 0.2m }
			 };

			bankingaccounts.ForEach(c => context.BankingAccounts.AddOrUpdate(p => p.ID, c));
			context.SaveChanges();
		}
	}
}
