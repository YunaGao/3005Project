﻿namespace BookStore
{
	public static class Constants
	{
        public const int PagedItems = 3;
		public const int NumberOfProductImages = 5;
	}
}