﻿using System.Collections.Generic;

namespace BookStore.Models
{
	public class Order
	{
		public int ID { get; set; }
		public string UserID { get; set; }
		public string DeliveryName { get; set; }
		public string DeliveryAddress { get; set; }
		public decimal TotalPrice { get; set; }
		public string Status { get; set; }
		public List<OrderItem> OrderLines { get; set; }
	}
}