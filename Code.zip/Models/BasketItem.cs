﻿namespace BookStore.Models
{
	public class BasketItem
	{
		public int ID { get; set; }
		public string BasketID { get; set; }
		public int BookID { get; set; }
		public int Amount { get; set; }
		public virtual Book Book { get; set; }
	}
}