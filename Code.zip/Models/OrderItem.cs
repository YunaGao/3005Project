﻿namespace BookStore.Models
{
	public class OrderItem
	{
		public int ID { get; set; }
		public int OrderID { get; set; }
		public int? BookID { get; set; }
		public int Amount { get; set; }
		public string BookName { get; set; }
		public decimal Price { get; set; }
		public virtual Book Book { get; set; }
		public virtual Order Order { get; set; }
	}
}