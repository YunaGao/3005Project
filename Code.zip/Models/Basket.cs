﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookStore.Models
{
	public class Basket
	{
		private string ID { get; set; }
		private const string BasketSessionKey = "BasketID";
		private StoreContext db = new StoreContext();
		private string GetBasketID()
		{
			if (HttpContext.Current.Session[BasketSessionKey] == null)
			{
				if(!string.IsNullOrWhiteSpace(HttpContext.Current.User.Identity.Name))
				{
					HttpContext.Current.Session[BasketSessionKey] = HttpContext.Current.User.Identity.Name;
				}
				else
				{
					Guid tempBasketID = Guid.NewGuid();
					HttpContext.Current.Session[BasketSessionKey] =
				   tempBasketID.ToString();
				}
			}
			return HttpContext.Current.Session[BasketSessionKey].ToString();
		}
		public static Basket GetBasket()
		{
			Basket basket = new Basket();
			basket.ID = basket.GetBasketID();
			return basket;
		}
		public void AddToBasket(int bookID, int amount)
		{
			var basketItem = db.BasketItems.FirstOrDefault(b => b.BasketID == ID && b.BookID == bookID);
			if (basketItem == null)
			{
				basketItem = new BasketItem
				{
					BookID = bookID,
					BasketID = ID,
					Amount = amount
				};
				db.BasketItems.Add(basketItem);
			}
			else
			{
				basketItem.Amount += amount;
			}
			db.SaveChanges();
		}

		public void RemoveItem(int productID)
		{
			var basketItem = db.BasketItems.FirstOrDefault(b => b.BasketID == ID
		   && b.BookID == productID);
			if (basketItem != null)
			{
				db.BasketItems.Remove(basketItem);
			}
			db.SaveChanges();
		}
		public void UpdateBasket(List<BasketItem> items)
		{
			foreach (var item in items)
			{
				var basketItem = db.BasketItems.FirstOrDefault(b => b.BasketID ==
			   ID && b.BookID == item.BookID);
				if (basketItem != null)
				{
					if (item.Amount == 0)
					{
						RemoveItem(item.BookID);
					}
					else
					{
						basketItem.Amount = item.Amount;
					}
				}
			}
			db.SaveChanges();
		}
		public void EmptyBasket()
		{
			var basketItems = db.BasketItems.Where(b => b.BasketID == ID);
			foreach (var item in basketItems)
			{
				db.BasketItems.Remove(item);
			}
			db.SaveChanges();
		}
		public List<BasketItem> GetBasketItems()
		{
			return db.BasketItems.Where(b => b.BasketID == ID).ToList();
		}
		public decimal GetTotalCost()
		{
			decimal basketTotal = decimal.Zero;
			if (GetBasketItems().Count > 0)
			{
				basketTotal = db.BasketItems.Where(b => b.BasketID == ID).Sum(b
			   => b.Book.Price * b.Amount);
			}
			return basketTotal;
		}
		public int GetNumberOfItems()
		{
			int numberOfItems = 0;
			if (GetBasketItems().Count > 0)
			{
				numberOfItems = db.BasketItems.Where(b => b.BasketID ==
			   ID).Sum(b => b.Amount);
			}
			return numberOfItems;
		}
		public void MigrateBasket(string userName)
		{
			var basket = db.BasketItems.Where(b => b.BasketID == ID).ToList();
			var usersBasket = db.BasketItems.Where(b => b.BasketID ==
		   userName).ToList();
			if (usersBasket != null)
			{
				string prevID = ID;
				ID = userName;
				foreach (var line in basket)
				{
					AddToBasket(line.BookID, line.BookID);
				}
				ID = prevID;
				EmptyBasket();
			}
			else
			{
				foreach (var item in basket)
				{
					item.BasketID = userName;
				}
				db.SaveChanges();
			}
			HttpContext.Current.Session[BasketSessionKey] = userName;
		}

		public decimal CreateOrderItems(int orderID)
		{
			decimal orderTotal = 0;
			var basketItems = GetBasketItems();
			foreach (var item in basketItems)
			{
				OrderItem orderItem = new OrderItem
				{
					Book = item.Book,
					BookID = item.BookID,
					BookName = item.Book.Name,
					Amount = item.Amount,
					Price = item.Book.Price,
					OrderID = orderID
				};
				orderTotal += (item.Amount * item.Book.Price);
				db.OrderItems.Add(orderItem);
			}
			db.SaveChanges();
			EmptyBasket();
			return orderTotal;
		}
	}
}
