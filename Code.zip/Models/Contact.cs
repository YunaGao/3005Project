﻿namespace BookStore.Models
{
	public class Contact
	{
		public int PublisherID { get; internal set; }
		public string Phone { get; internal set; }
		public int ID { get; internal set; }
	}
}