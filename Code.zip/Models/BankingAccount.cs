﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookStore.Models
{
	public class BankingAccount
	{
		[Key]
		[Column(Order = 1)]
		public int ID { get; set; }

		[Key]
		[Column(Order = 2)]
		public int BookId { get; set; }
		public decimal Percentage { get; set; }
	}
}