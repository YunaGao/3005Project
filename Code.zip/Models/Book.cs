﻿using System.Collections.Generic;

namespace BookStore.Models
{
	public class Book
	{
		public int ID { get; set; }
		public string Name { get; set; }
		public string ISBN { get; set; }
		public decimal Price { get; set; }
		public int Pages { get; set; }
		public int? PublisherId { get; set; }
		public virtual Publisher Publisher { get; set; }
		public virtual ICollection<Author> Authors { get; set; }
	}
}