﻿namespace BookStore.Models.ViewModels
{
	public class BasketSummaryViewModel
	{
		public int NumberOfItems { get; set; }
		public decimal TotalCost { get; set; }
	}
}