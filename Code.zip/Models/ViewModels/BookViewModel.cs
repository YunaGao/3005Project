﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace BookStore.Models.ViewModels
{
	public class BookViewModel
	{
		public int ID { get; set; }
		public string Name { get; set; }
		public string ISBN { get; set; }

		public decimal Price { get; set; }
		public int PublisherId { get; set; }
		public SelectList Publishers { get; set; }
		public List<SelectList> ImageLists { get; set; }
		public string[] ProductImages { get; set; }
	}
}
