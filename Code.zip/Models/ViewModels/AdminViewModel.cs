﻿namespace BookStore.Models.ViewModels
{
	public class AdminViewModel
	{
	}

	public class RoleViewModel
	{
		public string Id { get; set; }
		public string Name { get; set; }

	}
}