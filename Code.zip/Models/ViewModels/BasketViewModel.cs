﻿using System.Collections.Generic;

namespace BookStore.Models.ViewModels
{
	public class BasketViewModel
	{
		public List<BasketItem> BasketItems { get; set; }
		public decimal TotalCost { get; set; }
	}
}