﻿using System.Data.Entity;

namespace BookStore.Models
{
	public class StoreContext : DbContext
	{
		public StoreContext() : base("name=StoreContext")
		{
		}

		public DbSet<Author> Authors { get; set; }
		public DbSet<Contact> Contacts { get; set; }
		public DbSet<Publisher> Publishers { get; set; }
		public DbSet<BankingAccount> BankingAccounts { get; set; }
		public DbSet<Book> Books { get; set; }
		public DbSet<BasketItem> BasketItems { get; set; }
		public DbSet<Order> Orders { get; set; }
		public DbSet<OrderItem> OrderItems { get; set; }
	}
}