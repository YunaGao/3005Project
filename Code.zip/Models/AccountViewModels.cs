﻿using System.ComponentModel.DataAnnotations;

namespace BookStore.Models
{
	public class LoginViewModel
	{
		[Required]
		public string Name { get; set; }

		[Required]
		[DataType(DataType.Password)]
		[Display(Name = "Password")]
		public string Password { get; set; }
	}

	public class RegisterViewModel
	{
		public string Password { get; set; }
		public string ConfirmPassword { get; set; }
		public string Name { get; set; }
		public string Address { get; set; }	}
}
